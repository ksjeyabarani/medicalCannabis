# w241 Final Project [Fall 2020 - Section 1]

## **Experimentation on public opinion on medical cannabis for chronic pain**

**Team**:

Jeya Seenivasagam [ksjeyabarani@ischool.berkeley.edu - @kseenivasagam]

James Wall [james.wall@ischool.berkeley.edu - @jwall]

Surya Gutta [suryag@ischool.berkeley.edu - @sgutta]
